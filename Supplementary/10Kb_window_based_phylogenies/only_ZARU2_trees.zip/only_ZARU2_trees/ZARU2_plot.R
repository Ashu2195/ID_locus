##ZARU2
library(ape)

tree_dir <- "/media/ashutosh/sde2/FM_ID_project/vcf/entire_Z_vcf/10Kb_iqtree2/phy_iq/final_tree/only_ZARU2_trees"
tree_files <- list.files(tree_dir, pattern = "\\.treefile$", full.names = TRUE)

# Define tip labels and their corresponding colors
labels_to_color <- list(
  black = c("KADK1", "KADK2", "KADK3", "KADK4", "KADK5", "KADK6", "KADK7", "KADK8", "KADK9", "KADK10", 
            "SILK1", "SILK2", "SILK3", "SILK4", "SILK5", "SILK6", "SILK7", "SILK8", "SILK9", "SILK10", 
            "LCEM1", "LCEM2", "LCEM4", "LCJY3", "LCMC4", "LCMY2", "LCMY3", "LCMY4", "LCTF3", 
            "TCAB6", "TCDQ6", "TCGZ6", "XBBC1", "XBBC2", "XBBC3", "XBBC4", "XBBC5", "YOSK2", "YOSK4", "YOSK3", "YOSK1", "AYCM"),
  
  green = c("GVGJ1", "GVGJ2", "GVGJ3", "GVGJ4", "GVGJ5"),
  
  magenta = c("GLCJ1", "GLCJ2", "GLCJ3", "GLCJ4", "GLCJ5"),
  
  grey = c("GSGJ1", "GSGJ2", "GSGJ3"),
  
  red = c("RJFC1", "RJFC2", "RJFC3", "RJFC4", "RJFC5", "RJFC6", "RJFC7", "GGMI1", "GGMI2", "GGMI3", "GGSI1", "GGSI2"),
  
  blue = c("LCMY1", "TCAB3", "TCDQ1", "TCDQ3", "TCDQ4", "TCGZ3", "TCGZ5", "TCSN3", "TCSN4", "TCSN5", "TIBC7", 
           "NATC1", "NATC3", "NATC4", "NATC5", "NATC6", "NATC8", "KRNC1", "KRNC2", "KRNC3", "ETNC1", 
           "ETNC2", "ETNC3", "SLNC1", "SLNC2", "SLNC3", "XBFC1", "XBFC2", "XBFC3", "XBFC4", "XBFC5", 
           "XBFC6", "XBFC7", "XBFC8", "XBFC9", "XBFC10", "XBFC11", "XBFC12", "XBFC13", "XBFC14", "XBFC15", 
           "XBFC16", "XBFC17", "XBFC18", "XBFC19", "TLFC1", "TLFC2", "TLFC3", "TLFC4", "TLFC5", "TLFC6", 
           "LXFC6", "LXFC2", "LXFC3", "LXFC10", "LXFC9", "LXFC8", "LXFC7", "LXFC5", "LXFC4", "LXFC1", 
           "LXFC11", "LXFC12", "LXFC13", "LXFC14", "LXFC15", "LXFC16", "LXFC17", "LXFC18", "LXFC19", 
           "LXFC20", "LXFC21", "LXFC22", "LXFC23", "LXFC24", "LXFC25", "LXFC26", "LXFC27", "LXFC28", 
           "LXFC29", "LAFC1", "LAFC2", "LAFC3", "JSFC1", "JSFC2", "JSFC3", "JSFC4", "JSFC5", "MXFC1", 
           "JSFC6", "JSFC7", "JYFC1", "JYFC2", "COFC1", "PAFC1", "PEFC1", "PEFC2", "JAFC1", "JPFC1", 
           "JSFC8", "JSFC9", "JYFC3", "JSFC10", "BRFC1", "JPFC2", "JPFC3", "JSFC11", "TSFC1", "TSFC2", 
           "TSFC3", "INFC1", "SPFC1", "FRFC1", "PEFC3", "SPFC2", "USFC1", "MXFC2", "MXFC3", "JPFC4", 
           "JPFC5", "MXFC4", "PRFC1", "USFC2", "USFC3", "USFC4", "USFC5", "USFC6", "THFC", "ASFC", 
           "IAFC1", "IAFC2", "IAFC3", "IAFC4", "IAFC5", "IAFC6", "IAFC7", "IAFC8", "IAFC9", "IAFC10", 
           "IAFC11", "IAFC12", "IAFC13", "IAFC14","TBNC","TCGZ4", "TCGZ10", "NATC2"),
  
  orange = c("RIRL1", "RIRL2", "RIRL3", "RIRL4", "RIRL5", "RIRL6", "RIRL7", "RIRL8", "RIRL9", "RIRL10", 
             "RIRL11", "RIRL12", "RIRL13", "RIRL14", "RIRL15", "RIRL16", "RHIR1", "RHIR2", "RHIR3", 
             "BRLC1", "BRLC2", "BRLC3", "BRLC4", "BRLC5", "BRLC6", "BRLC7", "BRLC8", "BRLC9", "BRLC10", 
             "BRLC11", "BRLC12", "BRLC13", "BRLC14", "WHLH1", "WHLH2", "WHLH3", "WHLH4", "WHLH5", 
             "WHLH6", "WHLH7", "WHLH8", "WHLH9", "WHLH10", "WHLH11", "WHLH12", "WHLH13", "WHLH14", 
             "CWLH2", "CWLH3", "CWLH4", "CWLH1", "CWLH5", "CWLH6", "RLCC", "BROL", "BROL", "DGLC", 
             "DBLC", "SBFC", "WCBP")
)

pdf("ZARU2_phylogeny_in_10kB_windows.pdf", width = 8.5, height = 11)

for (tree_file in tree_files) {
  tree <- read.tree(tree_file)
  edge_colors <- rep("black", nrow(tree$edge))  # Keep edges black
  
  tip_colors <- rep("black", length(tree$tip.label))  # Default tip color is black
  
  # Loop through each color group
  for (color in names(labels_to_color)) {
    tips_to_color <- match(labels_to_color[[color]], tree$tip.label)
    
    for (tip in tips_to_color) {
      if (!is.na(tip)) {
        tip_colors[tip] <- color  # Assign color based on the group
      }
    }
  }

  # Extract chromosome, start, and end from the file name
  # Example of file name: "Z_80310000_80320000.min4.phy.treefile"
  file_info <- basename(tree_file)
  file_info <- gsub("\\.min4\\.phy\\.treefile$", "", file_info)  # Remove the suffix
  main_title <- file_info  # Set main title to the modified file name
  
  plot.phylo(tree, 
             main = main_title,  # Set main title to "chr_start_end"
             type = "fan", 
             use.edge.length = FALSE, 
             cex = 0.5, 
             edge.color = edge_colors, 
             tip.color = tip_colors)
}

dev.off()
